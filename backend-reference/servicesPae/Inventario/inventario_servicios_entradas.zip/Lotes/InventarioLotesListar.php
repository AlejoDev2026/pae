<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Cache-Control, Pragma, Expires, Authorization");
header("Access-Control-Max-Age: 0");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(204);
    exit;
}

require_once __DIR__ . "/../conexion.php";

function responder($rpta, $mensaje, $data = [], $extra = [], $codigoHttp = 200)
{
    http_response_code($codigoHttp);

    echo json_encode(
        array_merge([
            "rpta" => $rpta,
            "mensaje" => $mensaje,
            "data" => $data
        ], $extra),
        JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
    );

    exit;
}

if (!isset($conexion) || !$conexion instanceof mysqli) {
    responder(
        "no",
        "No se encontró la conexión a la base de datos",
        [],
        ["error" => "La variable \$conexion no está disponible"],
        500
    );
}

$conexion->set_charset("utf8mb4");

function limpiarTexto($valor)
{
    return trim((string)($valor ?? ""));
}

function parametro($nombre, $default = "")
{
    if (isset($_GET[$nombre])) {
        return limpiarTexto($_GET[$nombre]);
    }

    if (isset($_POST[$nombre])) {
        return limpiarTexto($_POST[$nombre]);
    }

    return $default;
}

function entradaJson()
{
    $raw = file_get_contents("php://input");
    $json = json_decode($raw, true);

    if (!is_array($json)) {
        return [];
    }

    return $json;
}

function esc($valor)
{
    global $conexion;
    return $conexion->real_escape_string((string)($valor ?? ""));
}

function fechaONull($valor)
{
    $valor = limpiarTexto($valor);

    if ($valor === "") {
        return "NULL";
    }

    return "'" . esc($valor) . "'";
}

function textoONull($valor)
{
    $valor = limpiarTexto($valor);

    if ($valor === "") {
        return "NULL";
    }

    return "'" . esc($valor) . "'";
}

function intONull($valor)
{
    if ($valor === null || $valor === "") {
        return "NULL";
    }

    $valor = intval($valor);

    if ($valor <= 0) {
        return "NULL";
    }

    return (string)$valor;
}

function decimalSeguro($valor)
{
    if ($valor === null || $valor === "") {
        return 0;
    }

    return round(floatval(str_replace(",", ".", (string)$valor)), 3);
}

function obtenerFila($sql)
{
    global $conexion;

    $res = $conexion->query($sql);

    if (!$res) {
        throw new Exception($conexion->error);
    }

    return $res->fetch_assoc() ?: null;
}

function obtenerFilas($sql)
{
    global $conexion;

    $res = $conexion->query($sql);

    if (!$res) {
        throw new Exception($conexion->error);
    }

    $data = [];

    while ($fila = $res->fetch_assoc()) {
        $data[] = $fila;
    }

    return $data;
}

try {
    $q = parametro("q", parametro("busqueda", ""));
    $idProducto = intval(parametro("idProducto", 0));
    $estado = parametro("estado", "");
    $limite = intval(parametro("limite", 100));

    if ($limite <= 0 || $limite > 500) {
        $limite = 100;
    }

    $where = [
        "1 = 1"
    ];

    if ($idProducto > 0) {
        $where[] = "l.idProducto = $idProducto";
    }

    if ($estado !== "") {
        $where[] = "l.estado = " . intval($estado);
    }

    if ($q !== "") {
        $qEsc = esc($q);
        $like = "%" . $qEsc . "%";

        $where[] = "
            (
                l.lote LIKE '$like'
                OR pc.codigo LIKE '$like'
                OR pc.descripcion LIKE '$like'
            )
        ";
    }

    $sql = "
        SELECT
            l.id,
            l.idProducto,
            l.lote,
            l.fechaFabricacion,
            l.fechaVencimiento,
            l.fechaIngreso,
            l.observacion,
            l.estado,
            l.created_at,
            l.updated_at,

            pc.codigo AS codigoProducto,
            pc.descripcion AS nombreProducto,

            pic.manejaLote,
            pic.manejaVencimiento,
            pic.unidadBaseInventario,

            COALESCE(SUM(ie.cantidadDisponible), 0) AS cantidadDisponible,
            COALESCE(SUM(ie.cantidadReservada), 0) AS cantidadReservada,
            COALESCE(SUM(ie.cantidadBloqueada), 0) AS cantidadBloqueada

        FROM InventarioLotes l

        INNER JOIN ProductosCatalogo pc
            ON pc.id = l.idProducto

        LEFT JOIN ProductosInventarioConfig pic
            ON pic.idProducto = pc.id

        LEFT JOIN InventarioExistencias ie
            ON ie.idLote = l.id

        WHERE " . implode(" AND ", $where) . "

        GROUP BY
            l.id,
            l.idProducto,
            l.lote,
            l.fechaFabricacion,
            l.fechaVencimiento,
            l.fechaIngreso,
            l.observacion,
            l.estado,
            l.created_at,
            l.updated_at,
            pc.codigo,
            pc.descripcion,
            pic.manejaLote,
            pic.manejaVencimiento,
            pic.unidadBaseInventario

        ORDER BY
            pc.descripcion ASC,
            l.fechaVencimiento IS NULL ASC,
            l.fechaVencimiento ASC,
            l.lote ASC

        LIMIT $limite
    ";

    $filas = obtenerFilas($sql);

    $data = [];

    foreach ($filas as $fila) {
        $data[] = [
            "idLote" => intval($fila["id"]),
            "id" => intval($fila["id"]),
            "idProducto" => intval($fila["idProducto"]),
            "lote" => (string)$fila["lote"],
            "fechaFabricacion" => $fila["fechaFabricacion"],
            "fechaVencimiento" => $fila["fechaVencimiento"],
            "fechaIngreso" => $fila["fechaIngreso"],
            "observacion" => $fila["observacion"],
            "estado" => intval($fila["estado"]),
            "estadoTexto" => intval($fila["estado"]) === 1 ? "Activo" : "Inactivo",
            "created_at" => $fila["created_at"],
            "updated_at" => $fila["updated_at"],

            "codigoProducto" => (string)$fila["codigoProducto"],
            "nombreProducto" => (string)$fila["nombreProducto"],
            "producto" => (string)$fila["nombreProducto"],

            "manejaLote" => intval($fila["manejaLote"] ?? 1),
            "manejaVencimiento" => intval($fila["manejaVencimiento"] ?? 1),
            "unidadBaseInventario" => (string)($fila["unidadBaseInventario"] ?? "UND"),

            "cantidadDisponible" => floatval($fila["cantidadDisponible"]),
            "cantidadReservada" => floatval($fila["cantidadReservada"]),
            "cantidadBloqueada" => floatval($fila["cantidadBloqueada"])
        ];
    }

    responder(
        "si",
        "Lotes consultados correctamente",
        $data,
        [
            "total" => count($data)
        ]
    );
} catch (Throwable $e) {
    responder(
        "no",
        "Error consultando lotes",
        [],
        ["error" => $e->getMessage()],
        500
    );
}
?>
