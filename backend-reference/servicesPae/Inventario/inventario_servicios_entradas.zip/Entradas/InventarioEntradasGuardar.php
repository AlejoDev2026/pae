<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Cache-Control, Pragma, Expires, Authorization");
header("Access-Control-Max-Age: 0");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(204);
    exit;
}

require_once __DIR__ . "/../conexion.php";

function responder($rpta, $mensaje, $data = [], $extra = [], $codigoHttp = 200)
{
    http_response_code($codigoHttp);

    echo json_encode(
        array_merge([
            "rpta" => $rpta,
            "mensaje" => $mensaje,
            "data" => $data
        ], $extra),
        JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
    );

    exit;
}

if (!isset($conexion) || !$conexion instanceof mysqli) {
    responder(
        "no",
        "No se encontró la conexión a la base de datos",
        [],
        ["error" => "La variable \$conexion no está disponible"],
        500
    );
}

$conexion->set_charset("utf8mb4");

function limpiarTexto($valor)
{
    return trim((string)($valor ?? ""));
}

function parametro($nombre, $default = "")
{
    if (isset($_GET[$nombre])) {
        return limpiarTexto($_GET[$nombre]);
    }

    if (isset($_POST[$nombre])) {
        return limpiarTexto($_POST[$nombre]);
    }

    return $default;
}

function entradaJson()
{
    $raw = file_get_contents("php://input");
    $json = json_decode($raw, true);

    if (!is_array($json)) {
        return [];
    }

    return $json;
}

function esc($valor)
{
    global $conexion;
    return $conexion->real_escape_string((string)($valor ?? ""));
}

function fechaONull($valor)
{
    $valor = limpiarTexto($valor);

    if ($valor === "") {
        return "NULL";
    }

    return "'" . esc($valor) . "'";
}

function textoONull($valor)
{
    $valor = limpiarTexto($valor);

    if ($valor === "") {
        return "NULL";
    }

    return "'" . esc($valor) . "'";
}

function intONull($valor)
{
    if ($valor === null || $valor === "") {
        return "NULL";
    }

    $valor = intval($valor);

    if ($valor <= 0) {
        return "NULL";
    }

    return (string)$valor;
}

function decimalSeguro($valor)
{
    if ($valor === null || $valor === "") {
        return 0;
    }

    return round(floatval(str_replace(",", ".", (string)$valor)), 3);
}

function obtenerFila($sql)
{
    global $conexion;

    $res = $conexion->query($sql);

    if (!$res) {
        throw new Exception($conexion->error);
    }

    return $res->fetch_assoc() ?: null;
}

function obtenerFilas($sql)
{
    global $conexion;

    $res = $conexion->query($sql);

    if (!$res) {
        throw new Exception($conexion->error);
    }

    $data = [];

    while ($fila = $res->fetch_assoc()) {
        $data[] = $fila;
    }

    return $data;
}

function generarConsecutivoEntrada()
{
    global $conexion;

    $prefijo = "ENT-" . date("Ymd") . "-";

    $fila = obtenerFila("
        SELECT consecutivo
        FROM InventarioDocumentos
        WHERE consecutivo LIKE '" . esc($prefijo) . "%'
        ORDER BY id DESC
        LIMIT 1
    ");

    $numero = 1;

    if ($fila && !empty($fila["consecutivo"])) {
        $partes = explode("-", $fila["consecutivo"]);
        $ultimo = intval(end($partes));
        $numero = $ultimo + 1;
    }

    return $prefijo . str_pad((string)$numero, 6, "0", STR_PAD_LEFT);
}

function obtenerOperadorPorUsuario($idUsuario)
{
    if ($idUsuario <= 0) {
        return null;
    }

    return obtenerFila("
        SELECT
            io.id AS idOperador,
            io.idUsuario,
            io.estado AS estadoOperador,
            u.estado AS estadoUsuario
        FROM InventarioOperadores io
        INNER JOIN usuarios u
            ON u.id = io.idUsuario
        WHERE
            io.idUsuario = $idUsuario
            AND io.estado = 1
            AND u.estado = 1
        LIMIT 1
    ");
}

function obtenerTipoDocumentoEntrada($idTipoDocumento)
{
    return obtenerFila("
        SELECT
            id,
            codigo,
            nombre,
            naturaleza,
            tipoMovimiento,
            afectaInventario,
            requiereOrigen,
            requiereDestino,
            permiteManual,
            estado
        FROM TiposDocumentoInventario
        WHERE id = $idTipoDocumento
        LIMIT 1
    ");
}

function obtenerProductoInventario($idProducto)
{
    return obtenerFila("
        SELECT
            pc.id,
            pc.codigo,
            pc.descripcion,
            pic.manejaLote,
            pic.manejaVencimiento,
            pic.unidadBaseInventario,
            pic.estado AS estadoInventario
        FROM ProductosCatalogo pc
        INNER JOIN ProductosInventarioConfig pic
            ON pic.idProducto = pc.id
        WHERE
            pc.id = $idProducto
            AND pc.estado = 1
            AND COALESCE(pc.idEstado, 1) = 1
            AND pic.estado = 1
        LIMIT 1
    ");
}

function validarBodega($idBodega)
{
    return obtenerFila("
        SELECT id, codigo, nombre
        FROM BodegasInventario
        WHERE id = $idBodega
            AND estado = 1
        LIMIT 1
    ");
}

function validarUbicacion($idUbicacion, $idBodega)
{
    if ($idUbicacion <= 0) {
        return null;
    }

    return obtenerFila("
        SELECT id, idBodega, codigo, nombre
        FROM UbicacionesInventario
        WHERE id = $idUbicacion
            AND idBodega = $idBodega
            AND estado = 1
        LIMIT 1
    ");
}

function obtenerOCrearLote($detalle, $producto)
{
    global $conexion;

    $idProducto = intval($producto["id"]);
    $manejaLote = intval($producto["manejaLote"]) === 1;
    $manejaVencimiento = intval($producto["manejaVencimiento"]) === 1;

    if (!$manejaLote) {
        return null;
    }

    $idLote = intval($detalle["idLote"] ?? 0);

    if ($idLote > 0) {
        $lote = obtenerFila("
            SELECT id, idProducto, lote, fechaVencimiento
            FROM InventarioLotes
            WHERE id = $idLote
                AND idProducto = $idProducto
                AND estado = 1
            LIMIT 1
        ");

        if (!$lote) {
            throw new Exception("El lote seleccionado no existe o no pertenece al producto " . $producto["descripcion"]);
        }

        if ($manejaVencimiento && empty($lote["fechaVencimiento"])) {
            throw new Exception("El producto " . $producto["descripcion"] . " maneja vencimiento y el lote seleccionado no tiene fecha de vencimiento.");
        }

        return intval($lote["id"]);
    }

    /*
     * Soporte adicional por si el frontend envía lote nuevo dentro de la línea.
     * El flujo visual recomendado es crear el lote desde el modal y enviar idLote.
     */
    $loteTexto = limpiarTexto($detalle["lote"] ?? ($detalle["numeroLote"] ?? ""));
    $fechaFabricacion = limpiarTexto($detalle["fechaFabricacion"] ?? "");
    $fechaVencimiento = limpiarTexto($detalle["fechaVencimiento"] ?? "");
    $fechaIngreso = limpiarTexto($detalle["fechaIngreso"] ?? date("Y-m-d"));
    $observacion = limpiarTexto($detalle["observacionLote"] ?? "");

    if ($loteTexto === "") {
        throw new Exception("Debe seleccionar o crear un lote para el producto " . $producto["descripcion"]);
    }

    if ($manejaVencimiento && $fechaVencimiento === "") {
        throw new Exception("Debe ingresar la fecha de vencimiento para el lote del producto " . $producto["descripcion"]);
    }

    $loteEsc = esc($loteTexto);

    $loteExistente = obtenerFila("
        SELECT id
        FROM InventarioLotes
        WHERE idProducto = $idProducto
            AND lote = '$loteEsc'
        LIMIT 1
    ");

    if ($loteExistente) {
        return intval($loteExistente["id"]);
    }

    $sqlInsertLote = "
        INSERT INTO InventarioLotes
        (
            idProducto,
            lote,
            fechaFabricacion,
            fechaVencimiento,
            fechaIngreso,
            observacion,
            estado,
            created_at,
            updated_at
        )
        VALUES
        (
            $idProducto,
            '$loteEsc',
            " . fechaONull($fechaFabricacion) . ",
            " . fechaONull($fechaVencimiento) . ",
            " . fechaONull($fechaIngreso) . ",
            " . textoONull($observacion) . ",
            1,
            NOW(),
            NOW()
        )
    ";

    if (!$conexion->query($sqlInsertLote)) {
        throw new Exception($conexion->error);
    }

    return intval($conexion->insert_id);
}

function obtenerExistenciaActual($idProducto, $idLote, $idBodega, $idUbicacion)
{
    $condLote = $idLote > 0
        ? "idLote = $idLote"
        : "idLote IS NULL";

    $condUbicacion = $idUbicacion > 0
        ? "idUbicacion = $idUbicacion"
        : "idUbicacion IS NULL";

    return obtenerFila("
        SELECT id, cantidadDisponible
        FROM InventarioExistencias
        WHERE
            idProducto = $idProducto
            AND $condLote
            AND idBodega = $idBodega
            AND $condUbicacion
        LIMIT 1
        FOR UPDATE
    ");
}

try {
    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        responder("no", "Método no permitido", [], [], 405);
    }

    $input = entradaJson();

    $idTipoDocumento = intval($input["idTipoDocumento"] ?? 0);
    $fechaDocumento = limpiarTexto($input["fechaDocumento"] ?? date("Y-m-d"));
    $observacion = limpiarTexto($input["observacion"] ?? "");
    $idUsuarioRegistro = intval($input["idUsuarioRegistro"] ?? $input["idUsuario"] ?? 0);
    $idOperador = intval($input["idOperador"] ?? 0);
    $detalles = $input["detalles"] ?? $input["productos"] ?? [];

    if ($idTipoDocumento <= 0) {
        responder("no", "Debe seleccionar el tipo de documento de entrada");
    }

    if ($idUsuarioRegistro <= 0) {
        responder("no", "Debe enviar el usuario que registra la entrada");
    }

    if (!is_array($detalles) || count($detalles) === 0) {
        responder("no", "Debe agregar al menos un producto a la entrada");
    }

    $tipoDocumento = obtenerTipoDocumentoEntrada($idTipoDocumento);

    if (!$tipoDocumento) {
        responder("no", "El tipo de documento seleccionado no existe");
    }

    if (intval($tipoDocumento["estado"]) !== 1) {
        responder("no", "El tipo de documento seleccionado está inactivo");
    }

    if (!in_array($tipoDocumento["naturaleza"], ["ENTRADA", "INVENTARIO_INICIAL"], true)) {
        responder("no", "El tipo de documento seleccionado no corresponde a una entrada");
    }

    if (intval($tipoDocumento["afectaInventario"]) !== 1) {
        responder("no", "El tipo de documento seleccionado no afecta inventario");
    }

    if ($idOperador <= 0) {
        $operador = obtenerOperadorPorUsuario($idUsuarioRegistro);

        if (!$operador) {
            responder("no", "El usuario no tiene operador activo para registrar movimientos de inventario");
        }

        $idOperador = intval($operador["idOperador"]);
    }

    $conexion->begin_transaction();

    $consecutivo = generarConsecutivoEntrada();

    $sqlDocumento = "
        INSERT INTO InventarioDocumentos
        (
            idTipoDocumento,
            idUsuarioRegistro,
            idOperador,
            consecutivo,
            fechaDocumento,
            idResponsable,
            idOperadorAsignado,
            idEstado,
            tipoOrigen,
            observacion,
            created_at,
            updated_at
        )
        VALUES
        (
            $idTipoDocumento,
            $idUsuarioRegistro,
            $idOperador,
            '" . esc($consecutivo) . "',
            " . fechaONull($fechaDocumento) . ",
            $idUsuarioRegistro,
            $idOperador,
            1,
            'MANUAL',
            " . textoONull($observacion) . ",
            NOW(),
            NOW()
        )
    ";

    if (!$conexion->query($sqlDocumento)) {
        throw new Exception($conexion->error);
    }

    $idDocumento = intval($conexion->insert_id);
    $totalCantidad = 0;
    $totalProductos = 0;
    $detallesGuardados = [];

    foreach ($detalles as $indice => $detalle) {
        $linea = $indice + 1;

        $idProducto = intval($detalle["idProducto"] ?? 0);
        $cantidad = decimalSeguro($detalle["cantidad"] ?? $detalle["cantidadProcesada"] ?? 0);
        $idBodega = intval($detalle["idBodega"] ?? 0);
        $idUbicacion = intval($detalle["idUbicacion"] ?? 0);
        $unidad = limpiarTexto($detalle["unidad"] ?? "");
        $observacionDetalle = limpiarTexto($detalle["observacion"] ?? "");

        if ($idProducto <= 0) {
            throw new Exception("La línea $linea no tiene producto seleccionado");
        }

        if ($cantidad <= 0) {
            throw new Exception("La línea $linea debe tener una cantidad mayor a cero");
        }

        if ($idBodega <= 0) {
            throw new Exception("La línea $linea debe tener bodega destino");
        }

        $producto = obtenerProductoInventario($idProducto);

        if (!$producto) {
            throw new Exception("El producto de la línea $linea no está activo o no está configurado para inventario");
        }

        $bodega = validarBodega($idBodega);

        if (!$bodega) {
            throw new Exception("La bodega de la línea $linea no existe o está inactiva");
        }

        if ($idUbicacion > 0) {
            $ubicacion = validarUbicacion($idUbicacion, $idBodega);

            if (!$ubicacion) {
                throw new Exception("La ubicación de la línea $linea no pertenece a la bodega seleccionada o está inactiva");
            }
        }

        if ($unidad === "") {
            $unidad = $producto["unidadBaseInventario"] ?: "UND";
        }

        $idLote = obtenerOCrearLote($detalle, $producto);

        $sqlDetalle = "
            INSERT INTO InventarioDocumentoDetalle
            (
                idDocumento,
                idProducto,
                cantidadSolicitada,
                cantidadProcesada,
                unidad,
                observacion,
                created_at,
                updated_at
            )
            VALUES
            (
                $idDocumento,
                $idProducto,
                $cantidad,
                $cantidad,
                '" . esc($unidad) . "',
                " . textoONull($observacionDetalle) . ",
                NOW(),
                NOW()
            )
        ";

        if (!$conexion->query($sqlDetalle)) {
            throw new Exception($conexion->error);
        }

        $idDocumentoDetalle = intval($conexion->insert_id);

        $sqlDetalleLote = "
            INSERT INTO InventarioDocumentoDetalleLotes
            (
                idDocumentoDetalle,
                idLote,
                idBodega,
                idUbicacion,
                cantidad,
                observacion,
                created_at
            )
            VALUES
            (
                $idDocumentoDetalle,
                " . intONull($idLote) . ",
                $idBodega,
                " . intONull($idUbicacion) . ",
                $cantidad,
                " . textoONull($observacionDetalle) . ",
                NOW()
            )
        ";

        if (!$conexion->query($sqlDetalleLote)) {
            throw new Exception($conexion->error);
        }

        $existencia = obtenerExistenciaActual(
            $idProducto,
            intval($idLote),
            $idBodega,
            $idUbicacion
        );

        $saldoAnterior = 0;
        $saldoNuevo = $cantidad;

        if ($existencia) {
            $saldoAnterior = floatval($existencia["cantidadDisponible"]);
            $saldoNuevo = $saldoAnterior + $cantidad;
            $idExistencia = intval($existencia["id"]);

            $sqlExistencia = "
                UPDATE InventarioExistencias
                SET
                    cantidadDisponible = $saldoNuevo,
                    updated_at = NOW()
                WHERE id = $idExistencia
                LIMIT 1
            ";
        } else {
            $sqlExistencia = "
                INSERT INTO InventarioExistencias
                (
                    idProducto,
                    idLote,
                    idBodega,
                    idUbicacion,
                    cantidadDisponible,
                    cantidadReservada,
                    cantidadBloqueada,
                    updated_at
                )
                VALUES
                (
                    $idProducto,
                    " . intONull($idLote) . ",
                    $idBodega,
                    " . intONull($idUbicacion) . ",
                    $cantidad,
                    0,
                    0,
                    NOW()
                )
            ";
        }

        if (!$conexion->query($sqlExistencia)) {
            throw new Exception($conexion->error);
        }

        $tipoMovimiento = limpiarTexto($tipoDocumento["tipoMovimiento"] ?: "ENTRADA");

        $sqlMovimiento = "
            INSERT INTO InventarioMovimientos
            (
                idDocumento,
                idDocumentoDetalle,
                idProducto,
                idLote,
                idBodega,
                idUbicacion,
                tipoMovimiento,
                cantidad,
                saldoAnterior,
                saldoNuevo,
                idUsuario,
                fechaMovimiento,
                observacion,
                idUsuarioRegistro,
                idOperador
            )
            VALUES
            (
                $idDocumento,
                $idDocumentoDetalle,
                $idProducto,
                " . intONull($idLote) . ",
                $idBodega,
                " . intONull($idUbicacion) . ",
                '" . esc($tipoMovimiento) . "',
                $cantidad,
                $saldoAnterior,
                $saldoNuevo,
                $idUsuarioRegistro,
                NOW(),
                " . textoONull($observacionDetalle) . ",
                $idUsuarioRegistro,
                $idOperador
            )
        ";

        if (!$conexion->query($sqlMovimiento)) {
            throw new Exception($conexion->error);
        }

        $totalProductos++;
        $totalCantidad += $cantidad;

        $detallesGuardados[] = [
            "idDocumentoDetalle" => $idDocumentoDetalle,
            "idProducto" => $idProducto,
            "producto" => $producto["descripcion"],
            "cantidad" => $cantidad,
            "unidad" => $unidad,
            "idLote" => $idLote,
            "idBodega" => $idBodega,
            "idUbicacion" => $idUbicacion,
            "saldoAnterior" => $saldoAnterior,
            "saldoNuevo" => $saldoNuevo
        ];
    }

    $conexion->commit();

    responder(
        "si",
        "Entrada de inventario guardada correctamente",
        [
            "idDocumento" => $idDocumento,
            "idEntrada" => $idDocumento,
            "consecutivo" => $consecutivo,
            "fechaDocumento" => $fechaDocumento,
            "idTipoDocumento" => $idTipoDocumento,
            "idUsuarioRegistro" => $idUsuarioRegistro,
            "idOperador" => $idOperador,
            "totalProductos" => $totalProductos,
            "totalCantidad" => $totalCantidad,
            "detalles" => $detallesGuardados
        ]
    );
} catch (Throwable $e) {
    if (isset($conexion) && $conexion instanceof mysqli) {
        $conexion->rollback();
    }

    responder(
        "no",
        "Error guardando entrada de inventario",
        [],
        ["error" => $e->getMessage()],
        500
    );
}
?>
