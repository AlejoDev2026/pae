<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Cache-Control, Pragma, Expires, Authorization");
header("Access-Control-Max-Age: 0");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(204);
    exit;
}

require_once __DIR__ . "/../conexion.php";

function responder($rpta, $mensaje, $data = [], $extra = [], $codigoHttp = 200)
{
    http_response_code($codigoHttp);

    echo json_encode(
        array_merge([
            "rpta" => $rpta,
            "mensaje" => $mensaje,
            "data" => $data
        ], $extra),
        JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
    );

    exit;
}

if (!isset($conexion) || !$conexion instanceof mysqli) {
    responder(
        "no",
        "No se encontró la conexión a la base de datos",
        [],
        ["error" => "La variable \$conexion no está disponible"],
        500
    );
}

$conexion->set_charset("utf8mb4");

function limpiarTexto($valor)
{
    return trim((string)($valor ?? ""));
}

function parametro($nombre, $default = "")
{
    if (isset($_GET[$nombre])) {
        return limpiarTexto($_GET[$nombre]);
    }

    if (isset($_POST[$nombre])) {
        return limpiarTexto($_POST[$nombre]);
    }

    return $default;
}

function entradaJson()
{
    $raw = file_get_contents("php://input");
    $json = json_decode($raw, true);

    if (!is_array($json)) {
        return [];
    }

    return $json;
}

function esc($valor)
{
    global $conexion;
    return $conexion->real_escape_string((string)($valor ?? ""));
}

function fechaONull($valor)
{
    $valor = limpiarTexto($valor);

    if ($valor === "") {
        return "NULL";
    }

    return "'" . esc($valor) . "'";
}

function textoONull($valor)
{
    $valor = limpiarTexto($valor);

    if ($valor === "") {
        return "NULL";
    }

    return "'" . esc($valor) . "'";
}

function intONull($valor)
{
    if ($valor === null || $valor === "") {
        return "NULL";
    }

    $valor = intval($valor);

    if ($valor <= 0) {
        return "NULL";
    }

    return (string)$valor;
}

function decimalSeguro($valor)
{
    if ($valor === null || $valor === "") {
        return 0;
    }

    return round(floatval(str_replace(",", ".", (string)$valor)), 3);
}

function obtenerFila($sql)
{
    global $conexion;

    $res = $conexion->query($sql);

    if (!$res) {
        throw new Exception($conexion->error);
    }

    return $res->fetch_assoc() ?: null;
}

function obtenerFilas($sql)
{
    global $conexion;

    $res = $conexion->query($sql);

    if (!$res) {
        throw new Exception($conexion->error);
    }

    $data = [];

    while ($fila = $res->fetch_assoc()) {
        $data[] = $fila;
    }

    return $data;
}

try {
    $idDocumento = intval(parametro("idDocumento", parametro("idEntrada", parametro("id", 0))));

    if ($idDocumento <= 0) {
        responder("no", "Debe enviar el identificador de la entrada");
    }

    $documento = obtenerFila("
        SELECT
            d.id,
            d.idTipoDocumento,
            d.idUsuarioRegistro,
            d.idOperador,
            d.consecutivo,
            d.fechaDocumento,
            d.idResponsable,
            d.idOperadorAsignado,
            d.idEstado,
            d.tipoOrigen,
            d.observacion,
            d.created_at,
            d.updated_at,

            td.codigo AS codigoTipoDocumento,
            td.nombre AS nombreTipoDocumento,
            td.naturaleza,
            td.tipoMovimiento,

            u.nombre AS nombreUsuario,
            u.correo AS correoUsuario,
            u.telefono AS telefonoUsuario,

            io.codigo AS codigoOperador,
            io.nombreCompleto AS nombreOperador,
            io.documento AS documentoOperador,
            io.cargo AS cargoOperador,
            io.correo AS correoOperador,
            io.telefono AS telefonoOperador

        FROM InventarioDocumentos d

        INNER JOIN TiposDocumentoInventario td
            ON td.id = d.idTipoDocumento

        LEFT JOIN usuarios u
            ON u.id = d.idUsuarioRegistro

        LEFT JOIN InventarioOperadores io
            ON io.id = d.idOperador

        WHERE
            d.id = $idDocumento
            AND td.naturaleza IN ('ENTRADA', 'INVENTARIO_INICIAL')

        LIMIT 1
    ");

    if (!$documento) {
        responder("no", "No se encontró la entrada solicitada");
    }

    $detalles = obtenerFilas("
        SELECT
            dd.id AS idDocumentoDetalle,
            dd.idDocumento,
            dd.idProducto,
            dd.cantidadSolicitada,
            dd.cantidadProcesada,
            dd.unidad,
            dd.observacion AS observacionDetalle,
            dd.created_at AS detalleCreatedAt,

            pc.codigo AS codigoProducto,
            pc.descripcion AS nombreProducto,

            pic.manejaLote,
            pic.manejaVencimiento,
            pic.unidadBaseInventario,

            ddl.id AS idDocumentoDetalleLote,
            ddl.idLote,
            ddl.idBodega,
            ddl.idUbicacion,
            ddl.cantidad AS cantidadLote,
            ddl.observacion AS observacionLoteDetalle,

            l.lote,
            l.fechaFabricacion,
            l.fechaVencimiento,
            l.fechaIngreso,
            l.observacion AS observacionLote,
            l.estado AS estadoLote,

            b.codigo AS codigoBodega,
            b.nombre AS nombreBodega,

            ub.codigo AS codigoUbicacion,
            ub.nombre AS nombreUbicacion

        FROM InventarioDocumentoDetalle dd

        INNER JOIN ProductosCatalogo pc
            ON pc.id = dd.idProducto

        LEFT JOIN ProductosInventarioConfig pic
            ON pic.idProducto = pc.id

        LEFT JOIN InventarioDocumentoDetalleLotes ddl
            ON ddl.idDocumentoDetalle = dd.id

        LEFT JOIN InventarioLotes l
            ON l.id = ddl.idLote

        LEFT JOIN BodegasInventario b
            ON b.id = ddl.idBodega

        LEFT JOIN UbicacionesInventario ub
            ON ub.id = ddl.idUbicacion

        WHERE dd.idDocumento = $idDocumento

        ORDER BY
            dd.id ASC,
            ddl.id ASC
    ");

    $movimientos = obtenerFilas("
        SELECT
            m.id,
            m.idDocumento,
            m.idDocumentoDetalle,
            m.idProducto,
            m.idLote,
            m.idBodega,
            m.idUbicacion,
            m.tipoMovimiento,
            m.cantidad,
            m.saldoAnterior,
            m.saldoNuevo,
            m.idUsuario,
            m.fechaMovimiento,
            m.observacion,
            m.idUsuarioRegistro,
            m.idOperador,

            pc.codigo AS codigoProducto,
            pc.descripcion AS nombreProducto,
            l.lote,
            b.nombre AS nombreBodega,
            ub.nombre AS nombreUbicacion

        FROM InventarioMovimientos m

        INNER JOIN ProductosCatalogo pc
            ON pc.id = m.idProducto

        LEFT JOIN InventarioLotes l
            ON l.id = m.idLote

        LEFT JOIN BodegasInventario b
            ON b.id = m.idBodega

        LEFT JOIN UbicacionesInventario ub
            ON ub.id = m.idUbicacion

        WHERE m.idDocumento = $idDocumento

        ORDER BY
            m.fechaMovimiento ASC,
            m.id ASC
    ");

    $detallesNormalizados = [];

    foreach ($detalles as $fila) {
        $detallesNormalizados[] = [
            "idDocumentoDetalle" => intval($fila["idDocumentoDetalle"]),
            "idDocumento" => intval($fila["idDocumento"]),
            "idProducto" => intval($fila["idProducto"]),
            "codigoProducto" => $fila["codigoProducto"],
            "nombreProducto" => $fila["nombreProducto"],
            "producto" => $fila["nombreProducto"],
            "cantidadSolicitada" => floatval($fila["cantidadSolicitada"]),
            "cantidadProcesada" => floatval($fila["cantidadProcesada"]),
            "cantidad" => floatval($fila["cantidadLote"] ?? $fila["cantidadProcesada"]),
            "unidad" => $fila["unidad"],
            "observacion" => $fila["observacionDetalle"],
            "manejaLote" => intval($fila["manejaLote"] ?? 1),
            "manejaVencimiento" => intval($fila["manejaVencimiento"] ?? 1),
            "unidadBaseInventario" => $fila["unidadBaseInventario"] ?? "UND",

            "idDocumentoDetalleLote" => $fila["idDocumentoDetalleLote"] !== null ? intval($fila["idDocumentoDetalleLote"]) : null,
            "idLote" => $fila["idLote"] !== null ? intval($fila["idLote"]) : null,
            "lote" => $fila["lote"],
            "fechaFabricacion" => $fila["fechaFabricacion"],
            "fechaVencimiento" => $fila["fechaVencimiento"],
            "fechaIngreso" => $fila["fechaIngreso"],
            "estadoLote" => $fila["estadoLote"] !== null ? intval($fila["estadoLote"]) : null,

            "idBodega" => $fila["idBodega"] !== null ? intval($fila["idBodega"]) : null,
            "codigoBodega" => $fila["codigoBodega"],
            "nombreBodega" => $fila["nombreBodega"],

            "idUbicacion" => $fila["idUbicacion"] !== null ? intval($fila["idUbicacion"]) : null,
            "codigoUbicacion" => $fila["codigoUbicacion"],
            "nombreUbicacion" => $fila["nombreUbicacion"]
        ];
    }

    $movimientosNormalizados = [];

    foreach ($movimientos as $fila) {
        $movimientosNormalizados[] = [
            "idMovimiento" => intval($fila["id"]),
            "id" => intval($fila["id"]),
            "idDocumento" => $fila["idDocumento"] !== null ? intval($fila["idDocumento"]) : null,
            "idDocumentoDetalle" => $fila["idDocumentoDetalle"] !== null ? intval($fila["idDocumentoDetalle"]) : null,
            "idProducto" => intval($fila["idProducto"]),
            "codigoProducto" => $fila["codigoProducto"],
            "nombreProducto" => $fila["nombreProducto"],
            "idLote" => $fila["idLote"] !== null ? intval($fila["idLote"]) : null,
            "lote" => $fila["lote"],
            "idBodega" => intval($fila["idBodega"]),
            "nombreBodega" => $fila["nombreBodega"],
            "idUbicacion" => $fila["idUbicacion"] !== null ? intval($fila["idUbicacion"]) : null,
            "nombreUbicacion" => $fila["nombreUbicacion"],
            "tipoMovimiento" => $fila["tipoMovimiento"],
            "cantidad" => floatval($fila["cantidad"]),
            "saldoAnterior" => floatval($fila["saldoAnterior"]),
            "saldoNuevo" => floatval($fila["saldoNuevo"]),
            "fechaMovimiento" => $fila["fechaMovimiento"],
            "observacion" => $fila["observacion"],
            "idUsuarioRegistro" => $fila["idUsuarioRegistro"] !== null ? intval($fila["idUsuarioRegistro"]) : null,
            "idOperador" => $fila["idOperador"] !== null ? intval($fila["idOperador"]) : null
        ];
    }

    $totalCantidad = 0;

    foreach ($detallesNormalizados as $detalle) {
        $totalCantidad += floatval($detalle["cantidad"]);
    }

    responder(
        "si",
        "Detalle de entrada consultado correctamente",
        [
            "documento" => [
                "idDocumento" => intval($documento["id"]),
                "idEntrada" => intval($documento["id"]),
                "id" => intval($documento["id"]),
                "idTipoDocumento" => intval($documento["idTipoDocumento"]),
                "consecutivo" => $documento["consecutivo"],
                "fechaDocumento" => $documento["fechaDocumento"],
                "idEstado" => $documento["idEstado"] !== null ? intval($documento["idEstado"]) : null,
                "estadoTexto" => intval($documento["idEstado"] ?? 1) === 1 ? "Activo" : "Inactivo",
                "tipoOrigen" => $documento["tipoOrigen"],
                "observacion" => $documento["observacion"],
                "created_at" => $documento["created_at"],
                "updated_at" => $documento["updated_at"],

                "codigoTipoDocumento" => $documento["codigoTipoDocumento"],
                "nombreTipoDocumento" => $documento["nombreTipoDocumento"],
                "naturaleza" => $documento["naturaleza"],
                "tipoMovimiento" => $documento["tipoMovimiento"],

                "idUsuarioRegistro" => $documento["idUsuarioRegistro"] !== null ? intval($documento["idUsuarioRegistro"]) : null,
                "nombreUsuario" => $documento["nombreUsuario"],
                "correoUsuario" => $documento["correoUsuario"],
                "telefonoUsuario" => $documento["telefonoUsuario"],

                "idOperador" => $documento["idOperador"] !== null ? intval($documento["idOperador"]) : null,
                "codigoOperador" => $documento["codigoOperador"],
                "nombreOperador" => $documento["nombreOperador"],
                "documentoOperador" => $documento["documentoOperador"],
                "cargoOperador" => $documento["cargoOperador"],
                "correoOperador" => $documento["correoOperador"],
                "telefonoOperador" => $documento["telefonoOperador"],

                "totalProductos" => count($detallesNormalizados),
                "totalCantidad" => $totalCantidad
            ],
            "detalles" => $detallesNormalizados,
            "movimientos" => $movimientosNormalizados
        ]
    );
} catch (Throwable $e) {
    responder(
        "no",
        "Error consultando detalle de entrada",
        [],
        ["error" => $e->getMessage()],
        500
    );
}
?>
