<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Cache-Control, Pragma, Expires, Authorization");
header("Access-Control-Max-Age: 0");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(204);
    exit;
}

require_once __DIR__ . "/../conexion.php";

function responder($rpta, $mensaje, $data = [], $extra = [], $codigoHttp = 200)
{
    http_response_code($codigoHttp);

    echo json_encode(
        array_merge([
            "rpta" => $rpta,
            "mensaje" => $mensaje,
            "data" => $data
        ], $extra),
        JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
    );

    exit;
}

if (!isset($conexion) || !$conexion instanceof mysqli) {
    responder(
        "no",
        "No se encontró la conexión a la base de datos",
        [],
        ["error" => "La variable \$conexion no está disponible"],
        500
    );
}

$conexion->set_charset("utf8mb4");

function limpiarTexto($valor)
{
    return trim((string)($valor ?? ""));
}

function parametro($nombre, $default = "")
{
    if (isset($_GET[$nombre])) {
        return limpiarTexto($_GET[$nombre]);
    }

    if (isset($_POST[$nombre])) {
        return limpiarTexto($_POST[$nombre]);
    }

    return $default;
}

function entradaJson()
{
    $raw = file_get_contents("php://input");
    $json = json_decode($raw, true);

    if (!is_array($json)) {
        return [];
    }

    return $json;
}

function esc($valor)
{
    global $conexion;
    return $conexion->real_escape_string((string)($valor ?? ""));
}

function fechaONull($valor)
{
    $valor = limpiarTexto($valor);

    if ($valor === "") {
        return "NULL";
    }

    return "'" . esc($valor) . "'";
}

function textoONull($valor)
{
    $valor = limpiarTexto($valor);

    if ($valor === "") {
        return "NULL";
    }

    return "'" . esc($valor) . "'";
}

function intONull($valor)
{
    if ($valor === null || $valor === "") {
        return "NULL";
    }

    $valor = intval($valor);

    if ($valor <= 0) {
        return "NULL";
    }

    return (string)$valor;
}

function decimalSeguro($valor)
{
    if ($valor === null || $valor === "") {
        return 0;
    }

    return round(floatval(str_replace(",", ".", (string)$valor)), 3);
}

function obtenerFila($sql)
{
    global $conexion;

    $res = $conexion->query($sql);

    if (!$res) {
        throw new Exception($conexion->error);
    }

    return $res->fetch_assoc() ?: null;
}

function obtenerFilas($sql)
{
    global $conexion;

    $res = $conexion->query($sql);

    if (!$res) {
        throw new Exception($conexion->error);
    }

    $data = [];

    while ($fila = $res->fetch_assoc()) {
        $data[] = $fila;
    }

    return $data;
}

try {
    $idUsuario = intval(parametro("idUsuario", parametro("idUsuarioRegistro", 0)));
    $idOperador = intval(parametro("idOperador", 0));
    $fechaDesde = parametro("fechaDesde", "");
    $fechaHasta = parametro("fechaHasta", "");
    $q = parametro("q", parametro("busqueda", ""));
    $limite = intval(parametro("limite", 100));

    if ($limite <= 0 || $limite > 500) {
        $limite = 100;
    }

    $where = [
        "td.naturaleza IN ('ENTRADA', 'INVENTARIO_INICIAL')"
    ];

    /*
     * Flujo visual: permite listar entradas hechas por el usuario logueado.
     * Si no llega idUsuario, retorna todas las entradas.
     */
    if ($idUsuario > 0) {
        $where[] = "d.idUsuarioRegistro = $idUsuario";
    }

    if ($idOperador > 0) {
        $where[] = "d.idOperador = $idOperador";
    }

    if ($fechaDesde !== "") {
        $where[] = "d.fechaDocumento >= '" . esc($fechaDesde) . "'";
    }

    if ($fechaHasta !== "") {
        $where[] = "d.fechaDocumento <= '" . esc($fechaHasta) . "'";
    }

    if ($q !== "") {
        $qEsc = esc($q);
        $like = "%" . $qEsc . "%";

        $where[] = "
            (
                d.consecutivo LIKE '$like'
                OR td.codigo LIKE '$like'
                OR td.nombre LIKE '$like'
                OR u.nombre LIKE '$like'
                OR io.nombreCompleto LIKE '$like'
                OR io.documento LIKE '$like'
                OR d.observacion LIKE '$like'
            )
        ";
    }

    $sql = "
        SELECT
            d.id,
            d.idTipoDocumento,
            d.idUsuarioRegistro,
            d.idOperador,
            d.consecutivo,
            d.fechaDocumento,
            d.idEstado,
            d.tipoOrigen,
            d.observacion,
            d.created_at,
            d.updated_at,

            td.codigo AS codigoTipoDocumento,
            td.nombre AS nombreTipoDocumento,
            td.naturaleza,
            td.tipoMovimiento,

            u.nombre AS nombreUsuario,
            u.correo AS correoUsuario,

            io.codigo AS codigoOperador,
            io.nombreCompleto AS nombreOperador,
            io.documento AS documentoOperador,
            io.cargo AS cargoOperador,

            COUNT(DISTINCT dd.id) AS totalProductos,
            COALESCE(SUM(dd.cantidadProcesada), 0) AS totalCantidad

        FROM InventarioDocumentos d

        INNER JOIN TiposDocumentoInventario td
            ON td.id = d.idTipoDocumento

        LEFT JOIN usuarios u
            ON u.id = d.idUsuarioRegistro

        LEFT JOIN InventarioOperadores io
            ON io.id = d.idOperador

        LEFT JOIN InventarioDocumentoDetalle dd
            ON dd.idDocumento = d.id

        WHERE " . implode(" AND ", $where) . "

        GROUP BY
            d.id,
            d.idTipoDocumento,
            d.idUsuarioRegistro,
            d.idOperador,
            d.consecutivo,
            d.fechaDocumento,
            d.idEstado,
            d.tipoOrigen,
            d.observacion,
            d.created_at,
            d.updated_at,
            td.codigo,
            td.nombre,
            td.naturaleza,
            td.tipoMovimiento,
            u.nombre,
            u.correo,
            io.codigo,
            io.nombreCompleto,
            io.documento,
            io.cargo

        ORDER BY
            d.fechaDocumento DESC,
            d.id DESC

        LIMIT $limite
    ";

    $filas = obtenerFilas($sql);

    $data = [];

    foreach ($filas as $fila) {
        $data[] = [
            "idDocumento" => intval($fila["id"]),
            "idEntrada" => intval($fila["id"]),
            "id" => intval($fila["id"]),
            "idTipoDocumento" => intval($fila["idTipoDocumento"]),
            "consecutivo" => $fila["consecutivo"],
            "fechaDocumento" => $fila["fechaDocumento"],
            "tipoOrigen" => $fila["tipoOrigen"],
            "observacion" => $fila["observacion"],
            "idEstado" => $fila["idEstado"] !== null ? intval($fila["idEstado"]) : null,
            "estadoTexto" => intval($fila["idEstado"] ?? 1) === 1 ? "Activo" : "Inactivo",
            "created_at" => $fila["created_at"],
            "updated_at" => $fila["updated_at"],

            "codigoTipoDocumento" => $fila["codigoTipoDocumento"],
            "nombreTipoDocumento" => $fila["nombreTipoDocumento"],
            "naturaleza" => $fila["naturaleza"],
            "tipoMovimiento" => $fila["tipoMovimiento"],

            "idUsuarioRegistro" => $fila["idUsuarioRegistro"] !== null ? intval($fila["idUsuarioRegistro"]) : null,
            "nombreUsuario" => $fila["nombreUsuario"],
            "correoUsuario" => $fila["correoUsuario"],

            "idOperador" => $fila["idOperador"] !== null ? intval($fila["idOperador"]) : null,
            "codigoOperador" => $fila["codigoOperador"],
            "nombreOperador" => $fila["nombreOperador"],
            "documentoOperador" => $fila["documentoOperador"],
            "cargoOperador" => $fila["cargoOperador"],

            "totalProductos" => intval($fila["totalProductos"]),
            "totalCantidad" => floatval($fila["totalCantidad"])
        ];
    }

    responder(
        "si",
        "Entradas consultadas correctamente",
        $data,
        [
            "total" => count($data),
            "filtros" => [
                "idUsuario" => $idUsuario,
                "idOperador" => $idOperador,
                "fechaDesde" => $fechaDesde,
                "fechaHasta" => $fechaHasta,
                "busqueda" => $q
            ]
        ]
    );
} catch (Throwable $e) {
    responder(
        "no",
        "Error consultando entradas de inventario",
        [],
        ["error" => $e->getMessage()],
        500
    );
}
?>
