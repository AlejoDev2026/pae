<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Cache-Control, Pragma, Expires, Authorization");
header("Access-Control-Max-Age: 0");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(204);
    exit;
}

require_once __DIR__ . "/../conexion.php";

function responder($rpta, $mensaje, $data = [], $extra = [], $codigoHttp = 200)
{
    http_response_code($codigoHttp);

    echo json_encode(
        array_merge([
            "rpta" => $rpta,
            "mensaje" => $mensaje,
            "data" => $data
        ], $extra),
        JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
    );

    exit;
}

if (!isset($conexion) || !$conexion instanceof mysqli) {
    responder(
        "no",
        "No se encontró la conexión a la base de datos",
        [],
        ["error" => "La variable \$conexion no está disponible"],
        500
    );
}

$conexion->set_charset("utf8mb4");

function limpiarTexto($valor)
{
    return trim((string)($valor ?? ""));
}

function parametro($nombre, $default = "")
{
    if (isset($_GET[$nombre])) {
        return limpiarTexto($_GET[$nombre]);
    }

    if (isset($_POST[$nombre])) {
        return limpiarTexto($_POST[$nombre]);
    }

    return $default;
}

function entradaJson()
{
    $raw = file_get_contents("php://input");
    $json = json_decode($raw, true);

    if (!is_array($json)) {
        return [];
    }

    return $json;
}

function esc($valor)
{
    global $conexion;
    return $conexion->real_escape_string((string)($valor ?? ""));
}

function fechaONull($valor)
{
    $valor = limpiarTexto($valor);

    if ($valor === "") {
        return "NULL";
    }

    return "'" . esc($valor) . "'";
}

function textoONull($valor)
{
    $valor = limpiarTexto($valor);

    if ($valor === "") {
        return "NULL";
    }

    return "'" . esc($valor) . "'";
}

function intONull($valor)
{
    if ($valor === null || $valor === "") {
        return "NULL";
    }

    $valor = intval($valor);

    if ($valor <= 0) {
        return "NULL";
    }

    return (string)$valor;
}

function decimalSeguro($valor)
{
    if ($valor === null || $valor === "") {
        return 0;
    }

    return round(floatval(str_replace(",", ".", (string)$valor)), 3);
}

function obtenerFila($sql)
{
    global $conexion;

    $res = $conexion->query($sql);

    if (!$res) {
        throw new Exception($conexion->error);
    }

    return $res->fetch_assoc() ?: null;
}

function obtenerFilas($sql)
{
    global $conexion;

    $res = $conexion->query($sql);

    if (!$res) {
        throw new Exception($conexion->error);
    }

    $data = [];

    while ($fila = $res->fetch_assoc()) {
        $data[] = $fila;
    }

    return $data;
}

try {
    $idUsuario = intval(parametro("idUsuario", parametro("idUsuarioRegistro", 0)));

    $tiposDocumento = obtenerFilas("
        SELECT
            id,
            codigo,
            nombre,
            naturaleza,
            tipoMovimiento,
            afectaInventario,
            requiereOrigen,
            requiereDestino,
            permiteManual,
            descripcion,
            estado
        FROM TiposDocumentoInventario
        WHERE
            estado = 1
            AND permiteManual = 1
            AND afectaInventario = 1
            AND naturaleza IN ('ENTRADA', 'INVENTARIO_INICIAL')
        ORDER BY
            naturaleza ASC,
            nombre ASC
    ");

    $bodegas = obtenerFilas("
        SELECT
            id,
            codigo,
            nombre,
            descripcion,
            estado
        FROM BodegasInventario
        WHERE estado = 1
        ORDER BY nombre ASC
    ");

    $ubicaciones = obtenerFilas("
        SELECT
            u.id,
            u.idBodega,
            u.codigo,
            u.nombre,
            u.descripcion,
            u.estado,
            b.codigo AS codigoBodega,
            b.nombre AS nombreBodega
        FROM UbicacionesInventario u
        INNER JOIN BodegasInventario b
            ON b.id = u.idBodega
        WHERE
            u.estado = 1
            AND b.estado = 1
        ORDER BY
            b.nombre ASC,
            u.nombre ASC
    ");

    $operador = null;

    if ($idUsuario > 0) {
        $operadorFila = obtenerFila("
            SELECT
                io.id AS idOperador,
                io.idUsuario,
                io.codigo,
                io.tipoDocumento,
                io.documento,
                io.nombre,
                io.apellido,
                io.nombreCompleto,
                io.telefono,
                io.correo,
                io.cargo,
                io.estado AS estadoOperador,
                u.nombre AS nombreUsuario,
                u.telefono AS telefonoUsuario,
                u.correo AS correoUsuario,
                u.estado AS estadoUsuario
            FROM InventarioOperadores io
            INNER JOIN usuarios u
                ON u.id = io.idUsuario
            WHERE
                io.idUsuario = $idUsuario
                AND io.estado = 1
                AND u.estado = 1
            LIMIT 1
        ");

        if ($operadorFila) {
            $nombre = trim((string)($operadorFila["nombreCompleto"] ?: $operadorFila["nombreUsuario"]));

            $operador = [
                "idOperador" => intval($operadorFila["idOperador"]),
                "idUsuario" => intval($operadorFila["idUsuario"]),
                "codigo" => $operadorFila["codigo"],
                "nombre" => $nombre,
                "nombreCompleto" => $nombre,
                "documento" => $operadorFila["documento"],
                "cargo" => $operadorFila["cargo"],
                "telefono" => $operadorFila["telefonoUsuario"] ?: $operadorFila["telefono"],
                "correo" => $operadorFila["correoUsuario"] ?: $operadorFila["correo"],
                "estadoOperador" => intval($operadorFila["estadoOperador"]),
                "estadoUsuario" => intval($operadorFila["estadoUsuario"])
            ];
        }
    }

    responder(
        "si",
        "Datos de formulario consultados correctamente",
        [
            "tiposDocumento" => array_map(function ($fila) {
                return [
                    "id" => intval($fila["id"]),
                    "idTipoDocumento" => intval($fila["id"]),
                    "codigo" => $fila["codigo"],
                    "nombre" => $fila["nombre"],
                    "naturaleza" => $fila["naturaleza"],
                    "tipoMovimiento" => $fila["tipoMovimiento"],
                    "afectaInventario" => intval($fila["afectaInventario"]),
                    "requiereOrigen" => intval($fila["requiereOrigen"]),
                    "requiereDestino" => intval($fila["requiereDestino"]),
                    "permiteManual" => intval($fila["permiteManual"]),
                    "descripcion" => $fila["descripcion"],
                    "estado" => intval($fila["estado"])
                ];
            }, $tiposDocumento),

            "bodegas" => array_map(function ($fila) {
                return [
                    "id" => intval($fila["id"]),
                    "idBodega" => intval($fila["id"]),
                    "codigo" => $fila["codigo"],
                    "nombre" => $fila["nombre"],
                    "descripcion" => $fila["descripcion"],
                    "estado" => intval($fila["estado"])
                ];
            }, $bodegas),

            "ubicaciones" => array_map(function ($fila) {
                return [
                    "id" => intval($fila["id"]),
                    "idUbicacion" => intval($fila["id"]),
                    "idBodega" => intval($fila["idBodega"]),
                    "codigo" => $fila["codigo"],
                    "nombre" => $fila["nombre"],
                    "descripcion" => $fila["descripcion"],
                    "codigoBodega" => $fila["codigoBodega"],
                    "nombreBodega" => $fila["nombreBodega"],
                    "estado" => intval($fila["estado"])
                ];
            }, $ubicaciones),

            "operador" => $operador,
            "fechaActual" => date("Y-m-d")
        ]
    );
} catch (Throwable $e) {
    responder(
        "no",
        "Error consultando datos de formulario de entrada",
        [],
        ["error" => $e->getMessage()],
        500
    );
}
?>
